<?php $__env->startSection('content'); ?>

<div class="col-lg-9 viewertbl">
  <div class="container">
      <div class="row">
          <div class="locationtbl col-lg-12">
              <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Admin settings</p>
          </div>
          <?php if(session()->has('err_message')): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('err_message')); ?>

            </div>
          <?php endif; ?>
          <?php if(session()->has('success_message')): ?>
            <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('success_message')); ?>

            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>

            <!-- Social -->
            <form role="form" class="mainform img-thumbnail mt-2 p-3" action="" method="post">
            <?php echo e(method_field('PUT')); ?>

            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="sitename">General site info</label>
                <?php if($siteinfo['sitename']==''): ?>
                  <input type="text" class="form-control" id="sitename" name="sitename" placeholder="Site name" value="<?php echo e($siteinfo['sitename']); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="sitename" name="sitename" placeholder="Site name">
                <?php endif; ?>
            </div>
                           
            <div class="form-group">
                <label for="sitename">Social Media</label>
                <!-- Facebook -->
                <?php if($siteinfo['facebook']==''): ?>
                  <input type="text" class="form-control" id="sitename" name="sitename" placeholder="Facebook page" value="<?php echo e($siteinfo['facebook']); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="sitename" name="sitename" placeholder="Facebook page">
                <?php endif; ?>
                <!-- Twitter -->
                <?php if($siteinfo['facebook']==''): ?>
                  <input type="text" class="form-control" id="twitter" name="twitter" placeholder="Twitter account" value="<?php echo e($siteinfo['twitter']); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="twitter" name="twitter" placeholder="Twitter account">
                <?php endif; ?>
                <!-- Youtube -->
                <?php if($siteinfo['facebook']==''): ?>
                  <input type="text" class="form-control" id="youtube" name="youtube" placeholder="Youtube channel" value="<?php echo e($siteinfo['youtube']); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="youtube" name="youtube" placeholder="Youtube channel">
                <?php endif; ?>
                <!-- Vimo -->
                <?php if($siteinfo['facebook']==''): ?>
                  <input type="text" class="form-control" id="vimo" name="vimo" placeholder="Vimo account" value="<?php echo e($siteinfo['vimo']); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="vimo" name="vimo" placeholder="Vimo account">
                <?php endif; ?>
            </div>


              <button type="submit" class="btn btn-primary subton">Save settings</button>

            </form>

          </div>
    </div>
</div>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views//cp/sitesettings.blade.php ENDPATH**/ ?>