<?php $__env->startSection('content'); ?>
<section class="category_main">
<div class="cate_layer">
    <div class="container">
        <div class="row series_row">

                <?php if(isset($thisseries)): ?>
                    <div class="col-lg-6 col-md-6 col-12 seriesinfo">
                        <div class="card" style="width: 18rem;">
                            <?php if($thispost->image_src == 'native'): ?>
                            <img class="card-img-top" src="<?php echo e(asset($thispost->image)); ?>" alt="Card image cap">
                            <?php else: ?>
                            <img class="card-img-top" src="<?php echo e($thispost->image); ?>" alt="Card image cap">
                            <?php endif; ?>
                            <div class="card-body">
                                <h5 class="card-title"><?php echo e($thisseries->seriesname); ?></h5>
                                <p class="card-text"><?php echo html_entity_decode($thisseries->content); ?></p>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-6 col-md-6 col-12 div_watch_others">
                        <div class="this_episode">
                            <?php if($thispost->downloadoption == 'Yes'): ?>
                            <h5><?php echo e($thispost->title); ?></h5>
                            <a href="/download/<?php echo e($thispost->id); ?>" class="btn btn-success">Download</a>
                            <a href="/watch/<?php echo e($thispost->id); ?>" class="btn btn-primary">Watch Episode</a>
                            <?php else: ?>
                            <h5><?php echo e($thispost->title); ?></h5>
                            <a href="/watch/<?php echo e($thispost->id); ?>" class="btn btn-primary">Watch episode</a>
                            <?php endif; ?>
                        </div>
                        
                        <div class="other_episodes">
                            <h6>Eepisodes List</h6>
                            <div class="episss">
                                <?php $__currentLoopData = $seriesposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seriespost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="/series/<?php echo e($seriespost->id); ?>" class="btn btn-sm btn-light"><?php echo e($seriespost->epn); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>

                <?php else: ?>
                    <div class="no_data_div">
                        <p>There is no posts in this series</p>
                    </div>
                <?php endif; ?>
        </div>
    </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\src\animaster\resources\views/series.blade.php ENDPATH**/ ?>