<?php $__env->startSection('content'); ?>
<section class="category_main down_category_main">
    <div class="cate_layer">
        <div class="container">
            <?php if(isset($thispost) && $thispost->downloadoption == 'Yes'): ?>
                <div class="downservers">
                    <div class="row">
                        <h5 class="col-12 mb-3">Download Servers</h5>
                        <?php if(isset($downserversnamefinal) && $downserversnamefinal != ''): ?>
                                <?php if($thispost->upvideo != ''): ?>
                                <a target="_blank" href="<?php echo e(asset($thispost->upvideo)); ?>" class="btn btn-light wserver dwserver"><?php echo e($sitename); ?></a>
                                <?php endif; ?>
                            <?php for($i = 0; $i<$downsercount; $i++): ?>
                                <a target="_blank" href="<?php echo e($downserverslinkfinal[$i]); ?>" class="btn btn-light wserver dwserver"><?php echo e($downserversnamefinal[$i]); ?></a>
                            <?php endfor; ?>
                        <?php else: ?>
                            <a target="_blank" href="<?php echo e(asset($thispost->upvideo)); ?>" class="btn btn-light wserver dwserver"><?php echo e($sitename); ?></a>
                        <?php endif; ?>
                    </div>
                </div>
            <?php else: ?>
                <div class="no_data_div">
                    <p>Not valid</p>
                </div>
            <?php endif; ?>

        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/download.blade.php ENDPATH**/ ?>