
  <div class="sidebar-slider">
                    <i class="fas fa-bars showsidediv"></i>
                </div>
                <div class="sidediv col-lg-3 order-0">
                    <nav id="sidebar" class="sidebar">
                        <div class="sidelayer"></div>
                            <div class="container row">
                                

                                <div class="avatarname col-12">
                                    <?php
                                        $adminimage = App\Admin::where('email', Auth::guard('admin')->user()->email)->first()->image;
                                    ?>
                                    <?php if(isset($adminimage) && $adminimage != ''): ?>
                                    <img src="<?php echo e(url('images/admin_images/admin_photoes/'.$adminimage.'')); ?>" class="img-thumbnail avatar">
                                    <?php else: ?>
                                    <img src="<?php echo e(url('images/admin_images/admin_photoes/default.png')); ?>" class="img-thumbnail avatar">
                                    <?php endif; ?>
                                    <div class="avatarname-body">
                                    <a  class="avatarname-name" href="<?php echo e(route('admin.getadminsettings')); ?>" class="d-block"><strong><?php echo e(ucwords(Auth::guard('admin')->user()->name)); ?></strong></a>
                                    </div>
                                </div>
                            
                                <ul class="list-unstyled components col-12">
                                    <li class="active">
                                        <?php if(session()->get('page') === 'dashboard'): ?>
                                        <a href="<?php echo e(route('dashboard.index')); ?>" class="cateactive main_list_item">
                                        <i class="fas fa-tachometer-alt"></i>
                                        Dashboard
                                        </a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('dashboard.index')); ?>" class="main_list_item">
                                        <i class="fas fa-tachometer-alt"></i>
                                        Dashboard
                                        </a>
                                        <?php endif; ?>
                                    </li>
                                    <li>
                                    <?php if(session()->get('page') === 'cates'): ?>
                                        <a href="<?php echo e(route('cp_categories.index')); ?>" data-class ="catesSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item cateactive">
                                            <i class="fas fa-list-alt"></i>
                                            Categories
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('cp_categories.index')); ?>" data-class ="catesSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item">
                                            <i class="fas fa-list-alt"></i>
                                            Categories
                                        </a>
                                    <?php endif; ?>
                                        <ul class="collapse list-unstyled" data="catesSubmenu" id="catesSubmenu">
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_categories.create')); ?>">Add category</a>
                                            </li>
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_categories.index')); ?>">Categories list</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                    <?php if(session()->get('page') === 'series'): ?>
                                        <a href="<?php echo e(route('cp_series.index')); ?>" data-class ="seriesSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item cateactive">
                                        <i class="fas fa-tv"></i>
                                            Series
                                        </a>
                                    <?php else: ?>
                                        <a href="<?php echo e(route('cp_series.index')); ?>" data-class ="seriesSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item">
                                        <i class="fas fa-tv"></i>
                                            Series
                                        </a>
                                    <?php endif; ?>
                                        <ul class="collapse list-unstyled" data="seriesSubmenu" id="seriesSubmenu">
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_series.create')); ?>">Add series</a>
                                            </li>
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_series.index')); ?>">Series list</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <?php if(session()->get('page') === 'posts'): ?>
                                        <a href="#" data-class ="postsSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item cateactive">
                                        <i class="fas fa-clone"></i>
                                            Posts
                                        </a>
                                        <?php else: ?>
                                        <a href="#" data-class ="postsSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item">
                                        <i class="fas fa-clone"></i>
                                            Posts
                                        </a>
                                        <?php endif; ?>
                                        <ul class="collapse list-unstyled" data="postsSubmenu" id="postsSubmenu">
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_posts.create')); ?>">Add post</a>
                                            </li>
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_posts.index')); ?>">Posts list</a>
                                            </li>
                                        </ul>
                                    </li>


                                    <li>
                                        <?php if(session()->get('page') === 'pages'): ?>
                                        <a href="<?php echo e(route('cp_pages.index')); ?>" data-class ="pagesSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item cateactive">
                                            <i class="fas fa-sticky-note"></i>
                                            Pages
                                        </a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('cp_pages.index')); ?>" data-class ="pagesSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item">
                                            <i class="fas fa-sticky-note"></i>
                                            Pages
                                        </a>
                                        <?php endif; ?>
                                        <ul class="collapse list-unstyled" data="pagesSubmenu" id="pagesSubmenu">
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_pages.create')); ?>">Add Page</a>
                                            </li>
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_pages.index')); ?>">Pages list</a>
                                            </li>
                                        </ul>
                                    </li>


                                    <li>
                                        <?php if(session()->get('page') === 'members'): ?>
                                        <a href="<?php echo e(route('cp_managemem.index')); ?>" data-class ="membersSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item cateactive">
                                            <i class="fas fa-users"></i>
                                            Members
                                        </a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('cp_managemem.index')); ?>" data-class ="membersSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item">
                                            <i class="fas fa-users"></i>
                                            Members
                                        </a>
                                        <?php endif; ?>
                                        <ul class="collapse list-unstyled" data="membersSubmenu" id="membersSubmenu">
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_managemem.create')); ?>">Add new member</a>
                                            </li>
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_managemem.index')); ?>">Manage members</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li>
                                        <?php if(session()->get('page') === 'comment'): ?>
                                        <a href="<?php echo e(route('cp_comment.index')); ?>"  data-class ="commentssSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item cateactive">
                                        <i class="fas fa-comments"></i>
                                            Comments
                                        </a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('cp_comment.index')); ?>"  data-class ="commentssSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item">
                                        <i class="fas fa-comments"></i>
                                            Comments
                                        </a>
                                        <?php endif; ?>
                                        <ul class="collapse list-unstyled" data="commentssSubmenu" id="commentssSubmenu">
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_comment.index')); ?>">Comments</a>
                                            </li>
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('comment.settings')); ?>">Comments settings</a>
                                            </li>
                                        </ul>
                                    <li>
                                        <?php if(session()->get('page') === 'message'): ?>
                                        <a href="<?php echo e(route('message.show')); ?>" class="cateactive main_list_item">
                                        <i class="fas fa-envelope"></i>
                                            Messages
                                        </a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('message.show')); ?>" class="main_list_item">
                                        <i class="fas fa-envelope"></i>
                                            Messages
                                        </a>
                                        <?php endif; ?>
                                    </li>
                                    <li>
                                    <?php if(session()->get('page') === 'settings'): ?>
                                        <a href="<?php echo e(route('cp_ssettings.index')); ?>" data-class ="settingsSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item cateactive">
                                            <i class="fas fa-cog"></i>
                                            Settings
                                        </a>
                                        <?php else: ?>
                                        <a href="<?php echo e(route('cp_ssettings.index')); ?>" data-class ="settingsSubmenu" data-toggle="collapse" aria-expanded="false" class="dropdown-toggle main_list_item">
                                            <i class="fas fa-cog"></i>
                                            Settings
                                        </a>
                                        <?php endif; ?>
                                        <ul class="collapse list-unstyled" data="settingsSubmenu" id="settingsSubmenu">
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('admin.getadminsettings')); ?>">Admin settings</a>
                                            </li>
                                            <li>
                                                <a class="sub_list_item" href="<?php echo e(route('cp_ssettings.index')); ?>">Site settings</a>
                                            </li>
                                        </ul>
                                    </li>
                                </ul>
                        </div>
                    </nav>
                </div><?php /**PATH C:\Users\H.Riad\Desktop\animasterpro\resources\views/cp/layouts/admin_sidebar.blade.php ENDPATH**/ ?>