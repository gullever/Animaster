<?php $__env->startSection('content'); ?>

<div class="col-lg-9 viewer" id="viewer">
                    <div class="viewer-layer"> </div>
                        <div class="container">
                            <div class="row p-3a">
                                <div class="location col-lg-12">
                                    <p>Dashboard \ Home</p>
                                </div>
                
                                <div class="stat">
                
                                    <div class="card img-thumbnail" style="width: 18rem;">
                                        <i class="fas sectstat fa-envelope fa-7x" style="color: #73808E;"></i>
                                        <div class="card-body">
                                            <p class="card-text">Unread messages: <?php echo e($countmsgs); ?></p>
                                            <a href="/shownewmessages" class="btn btn-sm btn-primary">View latest messages</a>
                                        </div>
                                      </div>
                
                                      <div class="card" style="width: 18rem;">
                                        <i class="fas sectstat fa-comments fa-7x" style="color: #73808E;"></i>
                                        <div class="card-body">
                                            <p class="card-text">Comments in the last 24 hours: <?php echo e($countcomments); ?></p>
                                            <a href="/cp_comments" class="btn btn-sm btn-primary">View latest comments</a>
                                        </div>
                                      </div>
                                    
                                      <div class="card" style="width: 18rem;">
                                        <i class="fas sectstat fa-user-friends fa-7x" style="color: #73808E;"></i>
                                        <div class="card-body">
                                            <p class="card-text">Registrants in the last 24 hours: <?php echo e($countusers); ?></p>
                                            <a href="<?php echo e(route('cp_managemem.index')); ?>" class="btn btn-sm btn-primary">View latest members</a>
                                        </div>
                                      </div>
                
                                </div>
                
                        </div>
                    </div>
                </div>
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\src\animaster\resources\views/cp/index.blade.php ENDPATH**/ ?>