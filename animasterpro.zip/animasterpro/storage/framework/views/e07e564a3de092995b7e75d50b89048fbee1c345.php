<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">
        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/bootstrap.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

    </head>
    <body>
      <div class="container-fluid">
        <div class="main-nav">
        <!-- Start upperbar --> 
            <div class="upperbar">
              <div class="container">
                <div class="row">

                <div class="col-lg-6 col-md-4 upperIcons">
                    <h6>Follow us</h6>
                    <a href="#"><i class="fab fa-facebook-square"></i></a>
                    <a href="#"><i class="fab fa-twitter-square"></i></a>
                    <a href="#"><i class="fab fa-youtube"></i></a>
                    <a href="#"><i class="fab fa-vimeo-square"></i></a>
                </div>


                <div class="col-lg-6 col-md-8 upperInfo">
                  <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Commodi</p>
                </div>

                </div>
            </div>
          </div>
        <!-- End upperbar --> 

        <!-- Start Navbar --> 
        <nav class="real-nav navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">

          <a class="navbar-brand col-xs-2" href="#">Animaster</a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse col-xs-10" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">

              

              <li class="nav-item active">
                <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
              </li>

              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Anime 
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">option</a>
                  <a class="dropdown-item" href="#">option</a>
                  <a class="dropdown-item" href="#">option</a>
                </div>
              </li>


              <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  Manga
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="#">option</a>
                  <a class="dropdown-item" href="#">option</a>
                  <a class="dropdown-item" href="#">option</a>
                </div>
              </li>


              <li class="nav-item">
                <a class="nav-link" href="#">Login / Register</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">About</a>
              </li>
              <li class="nav-item">
                <a class="nav-link" href="#">Contact</a>
              </li>

            </ul>
          </div>
          
          </div>
        </nav>
        <!-- End Navbar -->
      </div>


                <?php echo $__env->yieldContent('content'); ?>


    <!-- Start JS Scripts -->
    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('js/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
    <!-- End JS Scripts -->
      </div>
    </body>
</html><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/layout/app.blade.php ENDPATH**/ ?>