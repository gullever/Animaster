<?php $__env->startSection('content'); ?>

<div class="col-lg-9 viewertbl">
  <div class="container">
      <div class="row p-3">
          <div class="locationtbl col-lg-12">

          <?php if(isset($certainMem)): ?>
          <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Update member's information</p>
          <?php else: ?>
          <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Add new member</p>
          <?php endif; ?>

          </div>

          <?php if(session()->has('err_message')): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('err_message')); ?>

            </div>
          <?php endif; ?>
          <?php if(session()->has('success_message')): ?>
            <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('success_message')); ?>

            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>

          <?php if(isset($certainMem)): ?>
            <h3 class="card-title">Update member's information</h3>
          <?php else: ?>
            <h3 class="card-title">Add new Member</h3>
          <?php endif; ?>

          <?php if(isset($certainMem)): ?>
            <form role="form" class="mainform img-thumbnail mt-2 p-3" action="/cp_managemem/<?php echo e($certainMem->id); ?>" method="post">
            <?php echo e(method_field('PUT')); ?>

          <?php else: ?>
            <form role="form" class="mainform img-thumbnail mt-2 p-3" action="<?php echo e(route('cp_managemem.store')); ?>" method="post">
          <?php endif; ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="memnameid">Name</label>
                <?php if(isset($certainMem)): ?>
                  <input type="text" class="form-control" id="memnameid" name="memname" placeholder="Enter member name" value="<?php echo e($certainMem->name); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="memnameid" name="memname" placeholder="Enter member name">
                <?php endif; ?>
            </div>

            <div class="form-group">
                <label for="mememailid">Email</label>
                <?php if(isset($certainMem)): ?>
                  <input type="email" class="form-control" id="mememailid" name="email" placeholder="Enter member email" value="<?php echo e($certainMem->email); ?>">
                <?php else: ?>
                  <input type="email" class="form-control" id="mememailid" name="email" placeholder="Enter member email">
                <?php endif; ?>
            </div>

            <?php if(isset($certainMem)): ?>
            <div class="form-group">
                <label for="mempassid">Update password</label>
                <input type="password" class="form-control" id="mempassid" name="mempass" placeholder="Enter new password">
            </div>
            <?php endif; ?>
                           
            <div class="form-group">
                <?php if(isset($certainMem)): ?>
                  <div class="blockUser">
                      <div class="btn btn-sm btn-danger blockbtn mt-2">Block this member?</div>
                      <div class="bll">
                        <h6 class="mt-3">Insert period in days</h6>
                        <input type="number" name="blockperiod" id="blockperiod" class="form-control blockperiod">
                      </div>
                  </div>
                <?php else: ?>
                  <label for="mempassid">Password</label>
                  <input type="password" class="form-control" id="mempassid" name="mempass" placeholder="Enter member password">
                <?php endif; ?>
            </div>


            <?php if(isset($certainMem)): ?>

              <button type="submit" class="mt-4 btn btn-primary subton">Update</button>

            <?php else: ?>

              <button type="submit" class="mt-4 btn btn-primary subton">Add</button>

            <?php endif; ?>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/cp/members/cp_addmember.blade.php ENDPATH**/ ?>