<?php $__env->startSection('content'); ?>

<div class="col-lg-9 viewertbl_addpost">
    <div class="container">
        <div class="row p-3">
            <div class="locationtbl col-lg-12">
                <?php if(isset($requestedpost)): ?>
                    <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Edit post</p>
                <?php else: ?>
                    <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Add new post</p>
                <?php endif; ?>
            </div>

            <?php if(session()->has('err_message')): ?>
                <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
                    <?php echo e(session()->get('err_message')); ?>

                </div>
            <?php endif; ?>
            <?php if(session()->has('success_message')): ?>
                <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
                    <?php echo e(session()->get('success_message')); ?>

                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger adminSettingMsg col-12 mt-1">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
            <div class="card card-default bordcard">
                <?php if($cates->count() == 1 && $cates[0]->catename=="uncategorized"): ?>
                    <div class="catemsg" style="min-height: 100vh; min-width: 100%;">
                        <h5>There is no categories added yet</h5>
                        <a href="<?php echo e(route('cp_categories.create')); ?>" class="btn btn-primary">Add category</a>
                    </div>
                <?php else: ?>
                <div class="card-header">
                    <?php if(isset($requestedpost)): ?>
                    <h1 class="card-title" style="font-weight: bold; font-size: 20px">Create new post</h1>
                    <?php else: ?>
                    <h1 class="card-title" style="font-weight: bold; font-size: 20px">Edit post</h1>
                    <?php endif; ?>
                </div>
                <!-- /.card-header -->
                <div class="card-body">   
                    <?php if(isset($requestedpost)): ?>
                    <form action="/cp_posts/<?php echo e($requestedpost->id); ?>" id="uploadForm" class="postcreate" method="POST" enctype="multipart/form-data">
                    <?php echo e(method_field('PUT')); ?>

                    <?php else: ?>
                    <form action="<?php echo e(route('cp_posts.store')); ?>" id="uploadForm" class="postcreate" method="POST" enctype="multipart/form-data">
                    <?php echo e(method_field('POST')); ?>

                    <?php endif; ?>  
                    <?php echo csrf_field(); ?>
                        <div class="row"> 
                            <!--            Subject          -->
                            <div class="form-group col-12 border pt-3 pb-3">
                                <h5>Subject</h5>
                                <?php if(isset($requestedpost)): ?>
                                <input type="text" value="<?php echo e($requestedpost->title); ?>" name="title" class="form-control" id="title" placeholder="Post subject">
                                <?php else: ?>
                                <input type="text" name="title" class="form-control" id="title" placeholder="Post subject">
                                <?php endif; ?>
                            </div>

                            <!--           Episode Number          -->
                            <div class="form-group col-12 border pt-3 pb-3">
                                <h5>Episode number</h5>
                                <?php if(isset($requestedpost)): ?>
                                <input type="number" value="<?php echo e($requestedpost->epn); ?>" name="epn" class="form-control" id="epn" placeholder="Episode number">
                                <?php else: ?>
                                <input type="number" name="epn" class="form-control" id="epn" placeholder="Episode number">
                                <?php endif; ?>
                            </div>

                            <!--            Is it a series          -->
                            <div class="form-group col-12 border pt-3 pb-3">
                                <h5>Is your post belongs to a series?</h5>
                                <?php if(isset($requestedpost) && $requestedpost->series_id != ''): ?>
                                <p><b>Current series:</b> <?php echo e($requestedpost->series->seriesname); ?></p>
                                <?php elseif(isset($requestedpost) && $requestedpost->series_id == ''): ?>
                                <p><b>Current series:</b> No series</p>
                                <?php endif; ?>

                                <select id="selectvidtype" name="selectvidtype" class="form-control select2" style="width: 100%;">

                                    <?php if(isset($requestedpost) && $requestedpost->series_id != ''): ?>
                                        <option selected>Yes</option>
                                        <option>No</option>
                                    <?php elseif(isset($requestedpost) && $requestedpost->series_id == ''): ?>
                                        <option>Yes</option>
                                        <option selected>No</option>
                                    <?php else: ?>
                                        <option>Yes</option>
                                        <option selected>No</option>
                                    <?php endif; ?>

                                </select>
                            </div>
                                    <!--            Existing          -->   
                            <div class="form-group col-12 border pt-3 pb-3 existser">
                                <h6>Select series</h6>
                                <div class="existselect border">
                                    <select name="selectseries" id="selectseries" class="form-control">
                                    <?php if(isset($requestedpost) && $requestedpost->series_id != ''): ?>
                                            <option selected><?php echo e($seriesName); ?></option>
                                        <?php $__currentLoopData = $seriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($sera->seriesname != $seriesName): ?>
                                            <option><?php echo e($sera->seriesname); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php elseif(isset($requestedpost) && $requestedpost->series_id == ''): ?>
                                        <option selected></option>
                                        <?php $__currentLoopData = $seriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($sera->seriesname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    <?php elseif(isset($seriesList) && !isset($requestedpost)): ?>
                                        <option selected></option>
                                        <?php $__currentLoopData = $seriesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sera): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($sera->seriesname); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                    </select>
                                </div>
                            </div>
                        
                            <!--            Video upload and servers          -->
                            <div class="form-group col-12 border pt-3 pb-3">
                                <h5>Video upload and host links</h5>
                                <h6>Upload on your server</h6>

                                <?php if(isset($requestedpost) && $requestedpost->upvideo !=""): ?>
                                <h6 class="mt-3">Uploaded video</h6>
                                <video
                                id="my-player"
                                class="video-js"
                                controls
                                preload="auto"
                                onseeking="CallAction1();"
                                 onseeked="CallAction2();"
                                data-setup='{}'>
                                <source src="<?php echo e(asset($requestedpost->upvideo)); ?>" type="video/mp4"></source>
                                <source src="<?php echo e(asset($requestedpost->upvideo)); ?>" type="video/webm"></source>
                                <source src="<?php echo e(asset($requestedpost->upvideo)); ?>" type="video/ogg"></source>
                                <p class="vjs-no-js">
                                To view this video please enable JavaScript, and consider upgrading to a
                                web browser that
                                </p>
                                </video>
                                <?php endif; ?>

                                <?php if(isset($requestedpost) && $requestedpost->upvideo !=""): ?>
                                <div class="form-group border p-2 mt-3">
                                    <h6>Keep or remove old video</h6>
                                    <select class="form-control selectrmkvid col-12" id="selectrmkvid" name="selectrmkvid">
                                        <option selected value="yes">Keep this video</option>
                                        <option value="no">Remove it</option>
                                    </select>
                                </div>
                                <?php endif; ?>
                                
                                <div class="upload-video mt-4">
                                    <?php if(isset($requestedpost) && $requestedpost->upvideo !=""): ?>
                                        <h6>Update old video</h6>
                                    <?php endif; ?>
                                    <input type="file" name="postvidup"class="form-control-file" id="postvidup">
                                </div>

                                <div class="video-link mt-5">
                                    <h6>Remote host</h6>
                                    <div class="vid-url">
                                        <div class="vid-gather">
                                            <?php if(isset($requestedpost) && isset($watchserversnamefinal) && isset($watchsercount) && $watchsercount != 0): ?>
                                                <?php for($i=0; $i < $watchsercount; $i++): ?>
                                                    <div class="fullinput">
                                                        <div class="del_input">
                                                            <input type="text" value="<?php echo e($watchserversnamefinal[$i]); ?>" name="servername[]"class="form-control-file" id="postvidlink" placeholder="Server name">
                                                            <a class="btn btn-sm btn-primary rmvidlink"><i class="fas fa-minus text-white"></i></a>
                                                        </div>
                                                        <textarea name="vidcode[]" class="form-control" rows="5" id="comment" placeholder="code"><?php echo e($watchserverscodefinal[$i]); ?></textarea>
                                                    </div>
                                                <?php endfor; ?>
                                            <?php elseif(isset($watchsercount) && $watchsercount == 0): ?>

                                                <div class="fullinput">
                                                    <div class="del_input">
                                                            <input type="text"  name="servername[]"class="form-control-file" id="postvidlink" placeholder="Server name">
                                                        <a class="btn btn-sm btn-primary rmvidlink"><i class="fas fa-minus text-white"></i></a>
                                                    </div>
                                                    <textarea name="vidcode[]" class="form-control" rows="5" id="comment" placeholder="code"></textarea>
                                                </div>
                                            <?php else: ?>
                                                <div class="fullinput">
                                                    <div class="del_input">
                                                            <input type="text"  name="servername[]"class="form-control-file" id="postvidlink" placeholder="Server name">
                                                        <a class="btn btn-sm btn-primary rmvidlink"><i class="fas fa-minus text-white"></i></a>
                                                    </div>
                                                    <textarea name="vidcode[]" class="form-control" rows="5" id="comment" placeholder="code"></textarea>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                        <div class="options_del_add">
                                            <a class="btn btn-sm btn-primary addvidlink"><i class="fas fa-plus text-white"></i></a>
                                        </div>
                                    </div>
                            </div>
                            <!--            Download Choice          -->
                            <div class="form-group col-12 border pt-3 pb-3">
                                <h5>Download option</h5>
                                <p><i class="fas fa-exclamation-circle text-warning"></i> Determine whether you want to activate download option for visitor or no</p>
                                <select id="dwoption" name="dwoption" class="form-control select2" style="width: 100%;">
                                <?php if(isset($requestedpost) && $requestedpost->downloadoption == 'yes'): ?>
                                    <option selected>Yes</option>
                                    <option>No</option>
                                <?php elseif(isset($requestedpost) && $requestedpost->downloadoption == 'no'): ?>
                                    <option selected>No</option>
                                    <option>Yes</option>
                                <?php else: ?>
                                    <option selected>Yes</option>
                                    <option>No</option>
                                <?php endif; ?>
                                </select>
                            </div>
                            <!--            Download Links          -->           
                            <div class="form-group downlink-div col-12 border pt-3 pb-3">
                                <h5>Download link/s</h5>
                                <div class="vid-url mt-3">
                                    <div class="vid-gather-links">
                                    <?php if(isset($requestedpost) && isset($downserversnamefinal) && isset($downsercount) && $downsercount != 0): ?>
                                        <?php for($i=0; $i < $downsercount; $i++): ?>
                                            <div class="vid-fullinput">
                                                <div class="servname">
                                                    <input type="text" value="<?php echo e($downserversnamefinal[$i]); ?>" placeholder="Server name" class="form-control" name="servnameval[]">
                                                    <a class="btn btn-sm btn-primary rmvidlinkdw"><i class="fas fa-minus text-white"></i></a>
                                                </div>
                                                <div class="serlink">
                                                    <div class="icon-link"><i class="fas fa-link"></i></div>
                                                    <input type="text" value="<?php echo e($downserverslinkfinal[$i]); ?>" name="postvidlinkdwname[]" class="form-control-file" id="postvidlinkdw" placeholder="Download link">
                                                </div>
                                            </div>
                                        <?php endfor; ?>
                                    <?php elseif(isset($downsercount) && $downsercount == 0): ?>
                                        <div class="vid-fullinput">
                                            <div class="servname">
                                                <input type="text" placeholder="Server name" class="form-control" name="servnameval[]">
                                                <a class="btn btn-sm btn-primary rmvidlinkdw"><i class="fas fa-minus text-white"></i></a>
                                            </div>
                                            <div class="serlink">
                                                <div class="icon-link"><i class="fas fa-link"></i></div>
                                                <input type="text" name="postvidlinkdwname[]" class="form-control-file" id="postvidlinkdw" placeholder="Download link">
                                            </div>
                                        </div>
                                    <?php else: ?>
                                        <div class="vid-fullinput">
                                            <div class="servname">
                                                <input type="text" placeholder="Server name" class="form-control" name="servnameval[]">
                                                <a class="btn btn-sm btn-primary rmvidlinkdw"><i class="fas fa-minus text-white"></i></a>
                                            </div>
                                            <div class="serlink">
                                                <div class="icon-link"><i class="fas fa-link"></i></div>
                                                <input type="text" name="postvidlinkdwname[]" class="form-control-file" id="postvidlinkdw" placeholder="Download link">
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    </div>
                                </div>
                                <a class="btn btn-sm btn-primary addvidlinkdw"><i class="fas fa-plus text-white"></i></a>
                                </div>
                            </div>

                            <!--            Upload Image          --> 
                            <div class="form-group col-12 border pt-3 pb-3">
                                <h5>Post image</h5>
                                <?php if(isset($requestedpost)): ?>
                                <h6>Current post image</h6>
                                    <img class="img-thumbnail img-fluid mb-4" src="<?php echo e(asset($requestedpost->image)); ?>" alt="">
                                <?php endif; ?>
                                <div class="choose_img">
                                    <button id="choose_img-btn-1" data-class="upload-image" type="button" class="btn btn-primary">Upload</button>
                                    <button id="choose_img-btn-2" data-class="image-link" type="button" class="btn btn-primary">Insert an URL</button>
                                </div>

                                <div class="img_targets mt-4">

                                    <div class="upload-image">
                                        <h6>Upload Image</h6>
                                        <input type="file" name="postimgup"class="form-control-file" id="postimgup"> <!--later later-->
                                    </div>

                                    <div class="image-link">
                                        <h6>Image URL</h6>
                                        <div class="img-url border">
                                            <div class="icon-link"><i class="fas fa-link"></i></div>
                                            <?php if(isset($requestedpost) && $requestedpost->image_src != "native"): ?>
                                                 <input type="url" value="<?php echo e($requestedpost->image); ?>" name="postimglink"class="form-control-file" id="postimglink" style="display:block;">
                                            <?php else: ?>
                                                <input type="url" name="postimglink"class="form-control-file" id="postimglink">
                                            <?php endif; ?>
                                            
                                        </div>
                                    </div>
                                
                                </div>
                            </div>
                            <!--            Content          --> 
                            <div class="form-group content col-12 border pt-3 pb-3">
                                <h5 class="mb-3">Content <span class='text-muted'> (Optional)</span></h5>
                                <?php if(isset($requestedpost) && $requestedpost->content != ''): ?>
                                <textarea name="postcontent" class="textarea form-control postcontent" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" id="postcontent">
                                        <?php echo e($requestedpost->content); ?>

                                </textarea>
                                <?php else: ?>
                                <textarea name="postcontent" class="textarea form-control postcontent" placeholder="Place some text here" style="width: 100%; height: 200px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;" id="postcontent">
                                        
                                </textarea>
                                <?php endif; ?>

                            </div>
                            <!--            Tags          --> 
                            <div class="form-group col-12 border posttagsdiv pt-3 pb-3">
                                <h5>Tags <span class='text-muted'> (Optional but recommended)</span></h5>
                                <?php if(isset($requestedpost) && $requestedpost->tags != ''): ?>
                                     <input name="posttags" value="<?php echo e($requestedpost->tags); ?>" id="posttags" class="form-control posttags" type="text" data-role="tagsinput">
                                <?php else: ?>
                                    <input name="posttags" id="posttags" class="form-control posttags" type="text" data-role="tagsinput">
                                <?php endif; ?>
                                
                            </div>

                            <!--            Categories          -->        
                            <div class="form-group border catesub col-12">

                                <div class="form-group">
                                    <h5>Category</h5>
                                    <?php if(isset($requestedpost) && $requestedpost->category_id != ''): ?>
                                    <p><b>Current category:</b> <?php echo e($requestedpost->category->catename); ?></p>
                                    <?php elseif(isset($requestedpost) && $requestedpost->category_id == ''): ?>
                                    <p><b>Current category:</b> No category</p>
                                    <?php endif; ?>
                                    <select id="catelist" name="catelist" class="form-control select2 catelist" style="width: 100%;">
                                        <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($cate->catename != "uncategorized"): ?>
                                                <option><?php echo e($cate->catename); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                            </div>


                            <!--            Submit          --> 
                            <?php if(isset($requestedpost)): ?>
                            <div class="form-group sunmitdiv col-12">
                                <button type="submit" class="btn btn-success subton">Apply</button>
                            </div>
                            <?php else: ?>
                            <div class="form-group sunmitdiv col-12">
                                <button type="submit" class="btn btn-success subton">Create</button>
                            </div>
                             <?php endif; ?>


                        </div>
                        <!-- /.row -->
                    </form>
                </div>
                <!-- /.card-body -->
                <?php endif; ?>
            </div>
            <!-- /.card -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\src\animaster\resources\views/cp/posts/addpost.blade.php ENDPATH**/ ?>