<?php $__env->startSection('content'); ?>
<div class="col-lg-9 viewertbl">
  <div class="container">
    <div class="row p-3">
      <div class="locationtbl col-lg-12">
        <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Categories</p>
      </div>

      <?php if(session()->has('err_message')): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('err_message')); ?>

        </div>
      <?php endif; ?>
      <?php if(session()->has('success_message')): ?>
        <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('success_message')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
      <?php endif; ?>
      <div>
          <a href="<?php echo e(route('cp_categories.create')); ?>" class="btn btn-md btn-primary">Add new category</a>
      </div>
      <div class="view-table img-thumbnail">
        <table class="table">
          <thead>
            <tr class="firsttr">
              <th>#</th>
              <th>Name</th>
              <th>Number of posts</th>
              <th>Number of serieses</th>
              <th>Actions</th>
            </tr>
          </thead>
            <tbody>
            <?php $i = $catesList->perPage() * ($catesList->currentPage() - 1); ?>
                <?php $__currentLoopData = $catesList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                  <td><?php echo e($i++ + 1); ?></td>
                    <td><?php echo e($cate->catename); ?></td>
                    <td><?php echo e($cate->posts->count()); ?></td>
                    <td><?php echo e($cate->serieses->count()); ?></td>
                    <td class="actionscss">
                      <div class="row catetable">
                      <?php if($cate->catename == "uncategorized"): ?>
                        <a href="" data-class="cp_categories/<?php echo e($cate->id); ?>/del" class="del-category col-12"><i class="fas fa-trash-alt text-danger"></i></a>
                      <?php else: ?>
                        <a href="/cp_categories/<?php echo e($cate->id); ?>/edit"><i class="far fa-edit text-primary"></i></a><a href="" data-class="cp_categories/<?php echo e($cate->id); ?>/del" class="del-category"><i class="fas fa-trash-alt text-danger"></i></a>
                      <?php endif; ?>
                      </div>
                    </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>        
        <?php if(isset($emptycate)): ?>
            <p class="noCates">No categories added yet</p>
        <?php endif; ?>
      </div>
      <div class="card-footer clearfix">
          <?php echo e($catesList->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\src\animaster\resources\views/cp/categories/cp_categories.blade.php ENDPATH**/ ?>