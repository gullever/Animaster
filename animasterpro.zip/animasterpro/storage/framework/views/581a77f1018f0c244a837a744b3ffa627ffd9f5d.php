<?php $__env->startSection('content'); ?>
<section class="category_main">
<div class="cate_layer">
    <div class="container watchcontainer">
                <?php if(isset($thispost)): ?>
                    <div class="servers">
                        <div class="row">
                            <?php if(isset($watchserversnamefinal) && $watchserversnamefinal != ''): ?>
                                    <?php if($thispost->upvideo !=''): ?>
                                    <a data-class='<video id="my-player" class="video-js" controls preload="auto" onseeking="CallAction1();" onseeked="CallAction2();" data-setup="{}"><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/mp4"></source><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/webm"></source><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/ogg"></source><p class="vjs-no-js">To view this video please enable JavaScript, and consider upgrading to aweb browser that</p></video>' href="#" class="btn btn-light wserver"><?php echo e($sitename); ?></a>
                                    <?php endif; ?>
                                <?php for($i = 0; $i<$watchsercount; $i++): ?>
                                    <a data-class="<?php echo e($watchserverscodefinal[$i]); ?>" href="#" class="btn btn-light wserver"><?php echo e($watchserversnamefinal[$i]); ?></a>
                                <?php endfor; ?>
                            <?php else: ?>
                            <a data-class='<video id="my-player" class="video-js" controls preload="auto" onseeking="CallAction1();" onseeked="CallAction2();" data-setup="{}"><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/mp4"></source><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/webm"></source><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/ogg"></source><p class="vjs-no-js">To view this video please enable JavaScript, and consider upgrading to aweb browser that</p></video>' href="#" class="btn btn-light wserver"><?php echo e($sitename); ?></a>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="view_vid">
                    <?php if($thispost->upvideo !=''): ?>

                    <video id="my-player" class="video-js" controls preload="auto" onseeking="CallAction1();" onseeked="CallAction2();" data-setup="{}"><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/mp4"></source><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/webm"></source><source src="<?php echo e(asset($thispost->upvideo)); ?>" type="video/ogg"></source><p class="vjs-no-js">To view this video please enable JavaScript, and consider upgrading to aweb browser that</p></video>
                    
                    <?php else: ?>
                        <?php echo $watchserverscodefinal[0]; ?>

                    <?php endif; ?>
                    </div>

                    <div class="others_download">
                        <div class="row">
                            <?php if($thispost->downloadoption == 'Yes'): ?>
                                <div class="col-lg-3 col-md-3 col-9 downepi">
                                    <a href="/download/<?php echo e($thispost->id); ?>" class="btn btn-success">Download</a>
                                </div>
                                <div class="col-lg-2 col-md-2 col-3 downepi">
                                    <div class="access"><i class="fa fa-eye" aria-hidden="true"></i><small class="ml-2"><?php echo e($thispost->views == NULL ? 0 : $thispost->views); ?></small></div>
                                </div>
                                <div class="col-lg-7 col-md-7 col-12 other_epi">
                                    <h6>Eepisodes List</h6>
                                    <div class="epis">
                                        <?php $__currentLoopData = $seriesposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seriespost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="/watch/<?php echo e($seriespost->id); ?>" class="btn btn-sm btn-light"><?php echo e($seriespost->epn); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="col-12 tags p-2 mt-3">
                                
                                <?php
                                    $tags = explode(',', $thispost->tags);
                                    for($i=0; $i<count($tags); $i++)
                                    {
                                        echo $tags[$i].' ';
                                    }
                                ?>
                                </div>
                            <?php else: ?>
                                <div class="col-lg-2 col-12 downepi">
                                    <div class="access"><i class="fa fa-eye" aria-hidden="true"></i><small class="ml-2"><?php echo e($thispost->views == NULL ? 0 : $thispost->views); ?></small></div>
                                </div>
                                <div class="col-lg-10 col-12 other_epi">
                                    <h6>Eepisodes List</h6>
                                    <div class="epis">
                                        <?php $__currentLoopData = $seriesposts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seriespost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="/watch/<?php echo e($seriespost->id); ?>" class="btn btn-sm btn-light"><?php echo e($seriespost->epn); ?></a>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <!-- Facebook Comments-->
                    <?php 
                        $facecom = App\Site::where('id', 1)->first();
                        if(isset($facecom->facebookcomments) && $facecom->facebookcomments == "Yes")
                        {
                            $facecode = explode("AniMasTER4g3t319edoc670a4g84AniMASTer", $facecom->facecomcode);
                    ?>
                        <?php echo $facecode[1]; ?>

                    <?php
                        }
                    ?>                    
                    <!-- Site Comments -->
                    <?php
                    if(App\Site::where('id', 1)->first()->localcomments == "Yes")
                    {
                    ?>
                    <hr>
                    <div class="comments">
                        <h5>Comments</h5>
                        <?php if(session()->has('err_message')): ?>
                                <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
                                    <?php echo e(session()->get('err_message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('success_message')): ?>
                                <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
                                    <?php echo e(session()->get('success_message')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <div class="alert alert-danger adminSettingMsg col-12 mt-1">
                                    <ul>
                                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($error); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </div>
                            <?php endif; ?>

                        <?php if(Auth::check() || $adminauth == 1): ?>

                        <div class="new_comment pb-3">
                            <?php if(Auth::check()): ?>
                            <form action="/comment/<?php echo e(Auth::user()->id); ?>/post/<?php echo e($thispost->id); ?>" method="POST">
                            <?php else: ?>
                            <form action="/comment/<?php echo e(Auth::guard('admin')->id()); ?>/post/<?php echo e($thispost->id); ?>" method="POST">
                            <?php endif; ?>
                            <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="enter_comment">Write a comment</label>
                                    <textarea class="form-control" id="enter_comment" rows="3" name="memcomment" placeholder="Write a comment"></textarea>
                                </div>
                                <button class="btn btn-sm btn-primary">Comment</button>
                            </form>
                        </div>

                        <div class="comment_box img-thumbnail">
                            <?php if($postcomments->count() == 0): ?>
                            <div class="comm">
                                <div class="comm_text">
                                    <b>No Comments</b>
                                </div>
                            </div>
                            <?php else: ?>
                            <?php $__currentLoopData = $postcomments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comm">
                                <?php if($comment->role == "admin"): ?>
                                <span><b><?php echo e(App\Admin::where('id', 1)->first()->name); ?></b></span>
                                <?php else: ?>
                                <span><b><?php echo e($comment->user->name); ?></b></span>
                                <?php endif; ?>
                                <small><?php echo e($comment->created_at); ?></small>
                                <div class="comm_text img-thumbnail">
                                    <i><?php echo e($comment->value); ?></i>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <?php else: ?>
                        Please <a href="/register" class="logreg">register</a> or <a class="logreg" href="/login">login</a> to write a comment

                        <div class="comment_box img-thumbnail">
                            <?php if($postcomments->count() == 0): ?>
                            <div class="comm">
                                <div class="comm_text">
                                    <b>No Comments</b>
                                </div>
                            </div>
                            <?php else: ?>
                            <?php $__currentLoopData = $postcomments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="comm">
                                <span><b><?php echo e($comment->user->name); ?></b></span>
                                <small><?php echo e($comment->created_at); ?></small>
                                <div class="comm_text img-thumbnail">
                                    <i><?php echo e($comment->value); ?></i>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <?php
                    }
                    ?>

                <?php else: ?>
                    <div class="no_data_div">
                        <p>Not valid</p>
                    </div>
                <?php endif; ?>
        </div>
    </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/watch.blade.php ENDPATH**/ ?>