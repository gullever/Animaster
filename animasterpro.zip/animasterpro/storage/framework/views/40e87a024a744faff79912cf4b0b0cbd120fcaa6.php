<?php $__env->startSection('content'); ?>
<section class="category_main">
<div class="cate_layer">
    <div class="container">
        <div class="cate">
            <div class="row searcheadrow">
                <div class="searchhead p-2">
                <i class="fab fa-searchengin"></i><p class="card-text ml-1">Results for: <?php echo e($searchtext); ?></p>
                </div>
            </div>
                <div class="row searchpage">
                <?php if(isset($searchresults) && $searchresults->count() > 0): ?>
                    <?php $__currentLoopData = $searchresults; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $searchresult): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($searchresult->series_id == 0): ?>
                            <a href="/watch/<?php echo e($searchresult->id); ?>" class="col-lg-3 col-md-4 col-sm-6 col-12 epi_blk">
                        <?php else: ?>
                            <a href="/series/<?php echo e($searchresult->id); ?>" class="col-lg-3 col-md-4 col-sm-6 col-12 epi_blk">
                        <?php endif; ?>
                                <div class="card episodes_card">
                                <?php if($searchresult->image_src == 'native'): ?>
                                    <img src="<?php echo e(asset($searchresult->image)); ?>" class="card-img img-fluid card_img_top" alt="<?php echo e($searchresult->title); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e($searchresult->image); ?>" class="card-img img-fluid card_img_top" alt="<?php echo e($searchresult->title); ?>">
                                <?php endif; ?>
                                    <div class="card-body">
                                        <h7 class="card-title"><?php echo e($searchresult->title); ?></h7>
                                        <div class="access"><i class="fa fa-eye" aria-hidden="true"></i><small class="ml-2"><?php echo e($searchresult->views == NULL ? 0 : $searchresult->views); ?></small></div>
                                    </div>
                                </div>
                            </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <?php else: ?>
                <div class="no_data_div">
                    <p>Nothing found :(</p>
                </div>
            <?php endif; ?>
            <?php if(isset($searchresults)): ?>
                <?php echo e($searchresults->links()); ?>

            <?php endif; ?>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/search.blade.php ENDPATH**/ ?>