<?php $__env->startSection('content'); ?>

<div class="col-lg-9 viewertbl">
    <div class="container">
        <div class="row p-3">
          <div class="locationtbl col-lg-12">
              <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Admin settings</p>
          </div>
          <?php if(session()->has('err_message')): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('err_message')); ?>

            </div>
          <?php endif; ?>
          <?php if(session()->has('success_message')): ?>
            <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('success_message')); ?>

            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
            <?php endif; ?>


            <form role="form" class="mainform img-thumbnail mt-2 p-3" action="cp_ssettings/<?php echo e($siteinfo->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(method_field('PATCH')); ?>

            <?php echo csrf_field(); ?>
            <!-- Site -->
            <div class="form-group">
                <h5>General site info</h5>
                <?php if($siteinfo->sitename != null): ?>
                  <input type="text" class="form-control" id="sitename" name="sitename" placeholder="Site name" value="<?php echo e($siteinfo->sitename); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="sitename" name="sitename" placeholder="Site name">
                <?php endif; ?>
            </div>

            <div class="form-group">
                <h5>About website <span class="text-muted">(In Footer)<span></h5>
                <?php if($siteinfo->footerabout != null): ?>
                  <textarea class="form-control" id="footerabout" name="footerabout" placeholder="About website"><?php echo e($siteinfo->footerabout); ?></textarea>
                <?php else: ?>
                <textarea class="form-control" id="footerabout" name="footerabout" placeholder="About website"></textarea>
                <?php endif; ?>
            </div>
                           
            <div class="form-group">
                <h5>Social Media</h5>
                <p>Links should start with http:// or https://</p>
                <!-- Facebook -->
                <?php if($siteinfo->facebook != ''): ?>
                  <input type="text" class="form-control mb-2" id="facebook" name="facebook" placeholder="Facebook page" value="<?php echo e($siteinfo->facebook); ?>">
                <?php else: ?>
                  <input type="text" class="form-control mb-2" id="facebook" name="facebook" placeholder="Facebook page">
                <?php endif; ?>
                <!-- Twitter -->
                <?php if($siteinfo->twitter != ''): ?>
                  <input type="text" class="form-control mb-2" id="twitter" name="twitter" placeholder="Twitter account" value="<?php echo e($siteinfo->twitter); ?>">
                <?php else: ?>
                  <input type="text" class="form-control mb-2" id="twitter" name="twitter" placeholder="Twitter account">
                <?php endif; ?>
                <!-- Youtube -->
                <?php if($siteinfo->youtube != ''): ?>
                  <input type="text" class="form-control mb-2" id="youtube" name="youtube" placeholder="Youtube channel" value="<?php echo e($siteinfo->youtube); ?>">
                <?php else: ?>
                  <input type="text" class="form-control mb-2" id="youtube" name="youtube" placeholder="Youtube channel">
                <?php endif; ?>
                <!-- Vimo -->
                <?php if($siteinfo->vimo != ''): ?>
                  <input type="text" class="form-control" id="vimo" name="vimo" placeholder="Vimo account" value="<?php echo e($siteinfo->vimo); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="vimo" name="vimo" placeholder="Vimo account">
                <?php endif; ?>
            </div>

            <div class="form-group">
              <h5>Favicon</h5>
              <div class="custom-file">
                <input name="favicon" type="file" class="custom-file-input" id="customFile">
                <label class="custom-file-label" for="customFile">Choose file</label>
              </div>
            </div>

              <button type="submit" class="btn btn-primary subton form-control">Save settings</button>

            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/cp/sitesettings.blade.php ENDPATH**/ ?>