<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- Styles -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="<?php echo e(asset('css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link href="https://fonts.googleapis.com/css2?family=Cantora+One&family=Didact+Gothic&family=K2D:wght@100&family=Reem+Kufi&family=Sunflower:wght@300&display=swap" rel="stylesheet">
</head>

<body>

<!-- Facebook Comments -->
<?php 
  $facecom = App\Site::where('id', 1)->first();
  if(isset($facecom->facebookcomments) && $facecom->facebookcomments == "Yes")
  {
    $facecode = explode("AniMasTER4g3t319edoc670a4g84AniMASTer", $facecom->facecomcode);
?>
<?php echo $facecode[0]; ?>

<?php
  }
?>

<!-- End Facebook Comments -->

    <div class="container-fluid">
        <div class="main-nav">
        <!-- Start upperbar --> 
            <div class="upperbar">
              <div class="container">
                <div class="row">

                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 upperIcons">
                    <h6>Follow us</h6>
                    <?php

                        $siteinfo = App\Site::where('id', 1)->first();
                    ?>
                    
                    <a href="<?php echo e(isset($siteinfo) && $siteinfo->facebook ? $siteinfo->facebook : '#'); ?>" target="_blank"><i class="fab fa-facebook-square"></i></a>
                    <a href="<?php echo e(isset($siteinfo) && $siteinfo->twitter ? $siteinfo->twitter : '#'); ?>" target="_blank"><i class="fab fa-twitter-square"></i></a>
                    <a href="<?php echo e(isset($siteinfo) && $siteinfo->youtube ? $siteinfo->youtube : '#'); ?>" target="_blank"><i class="fab fa-youtube"></i></a>
                    <a href="<?php echo e(isset($siteinfo) && $siteinfo->vimo ? $siteinfo->vimo : '#'); ?>" target="_blank"><i class="fab fa-vimeo-square"></i></a>
                </div>

                <div class="input-group col-lg-6 col-md-6 col-sm-12 col-xs-12">
                  <form action="/search" class="mainsearchform" method="post">
                  <?php echo csrf_field(); ?>
                    <input class="form-control" type="text" name="searchvalue" placeholder="Search" aria-label="Search">

                      <div class="input-group-append">
                        <button href="" class="searchhyper">
                          <span class="input-group-text searchspan" id="basic-text1"><i class="fas fa-search text-grey" aria-hidden="true"></i></span>
                        </button>
                      </div>
                    </form>
                </div>

              </div>
            </div>
          </div>
        <!-- End upperbar --> 
        <!-- Start Navbar -->
        <nav class="real-nav navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">

          <a class="navbar-brand col-xs-2" href="/">
          
          <?php echo e(config('app.name', 'Laravel')); ?>


          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
          </button>

          <div class="collapse navbar-collapse col-xs-10" id="navbarNavDropdown">
            <ul class="navbar-nav ml-auto">

              

              <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(route('index.index')); ?>">Home <span class="sr-only">(current)</span></a>
              </li>
              <?php if(isset($cates) and $cates->count() > 0): ?>
                <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <?php if($cate->catename != 'uncategorized'): ?>
                    <li class="nav-item">
                      <a class="nav-link" href="/category/<?php echo e($cate->catename); ?>"><?php echo e($cate->catename); ?></a>
                    </li>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            <?php if(auth()->guard()->guest()): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Login')); ?></a>
                </li>
            <?php if(Route::has('register')): ?>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('register')); ?>"><?php echo e(__('Register')); ?></a>
                </li>
            <?php endif; ?>
            <?php else: ?>
                <li class="nav-item dropdown">
                    <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                        <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                        <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                        </a>

                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                        </form>
                    </div>
                </li>
            <?php endif; ?>

            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('message.message')); ?>">Contact</a>
            </li>

            <?php if(isset($pages) and $pages->count() > 0): ?>
              <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li class="nav-item">
                      <a class="nav-link" href="/page/<?php echo e($page->pagename); ?>"><?php echo e($page->pagename); ?></a>
                    </li>

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>

            </ul>
          </div>
          </div>
        </nav>
        <!-- End Navbar -->
        </div>

        <div class="contentcon">
                <?php echo $__env->yieldContent('content'); ?>
        </div>



    <!-- Start Footer -->
    <div class="footer" id="end_footer">
      <div class="container">
        <div class="upperfooter">
          <div class="row">

            <div class="col-lg-6 col-md-6 sitemap">
              <h5>Site Map</h5>
              <div class="row">
              <?php if(isset($cates) && $cates->count() > 0): ?>
              <div class="col-lg-4 col-md-4 col-sm-4">
                <ul class="list-unstyled">
                <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="/category/<?php echo e($cate->catename); ?>"><?php echo e($cate->catename); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
              </div>
              <?php endif; ?>

              <?php if(isset($pages) && $pages->count() > 0): ?>
              <div class="col-lg-4 col-md-4 col-sm-4">
                <ul class="list-unstyled">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><a href="/page/<?php echo e($page->pagename); ?>"><?php echo e($page->pagename); ?></a></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <li><a href="/sendmessage"">Contact</a></li>
                </ul>
              </div>
              <?php endif; ?>

              <div class="col-lg-4 col-md-4 col-sm-4">
                <ul class="list-unstyled">
                  <li><a href="/login">Login</a></li>
                  <li><a href="/register">Register</a></li>
                </ul>
              </div>

                  <div class="col-lg-12 social mt-4">
                    <a href="<?php echo e(isset($siteinfo) && $siteinfo->facebook ? $siteinfo->facebook : '#'); ?>" target="_blank"><i class="fab fa-facebook-square"></i></a>
                    <a href="<?php echo e(isset($siteinfo) && $siteinfo->twitter ? $siteinfo->twitter : '#'); ?>" target="_blank"><i class="fab fa-twitter-square"></i></a>
                    <a href="<?php echo e(isset($siteinfo) && $siteinfo->youtube ? $siteinfo->youtube : '#'); ?>" target="_blank"><i class="fab fa-youtube"></i></a>
                    <a href="<?php echo e(isset($siteinfo) && $siteinfo->vimo ? $siteinfo->vimo : '#'); ?>" target="_blank"><i class="fab fa-vimeo-square"></i></a>
                  </div>
              </div>
            </div>

            <div class="col-lg-6 col-md-6 contact">
              <h5>About</h5>
              <?php if(isset($siteinfo) && $siteinfo->footerabout): ?>
              <p><?php echo e($siteinfo->footerabout); ?></p>
              <?php else: ?>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Itaque ex, non sed vel aliquam, similique enim expedita dolor quis reiciendis beatae obcaecati totam fugiat magni at optio dolorem corrupti sapiente!</p>
              <?php endif; ?>
            </div>
          </div>

        </div>
        <div class="lowerfooter">
            <p>© 2020 Animaster All Rights Reserved</p>
        </div>
      </div>
    </div>
    <!-- End Footer -->

    <!-- Start JS Scripts -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src="<?php echo e(asset('js/plugins.js')); ?>"></script>
    <!-- End JS Scripts -->
      </div>
    </body>
</html><?php /**PATH C:\Users\H.Riad\Desktop\src\animaster\resources\views/layouts/app.blade.php ENDPATH**/ ?>