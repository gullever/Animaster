<?php $__env->startSection('content'); ?>
<div class="col-lg-9 viewertbl">
  <div class="container">
    <div class="row p-3">
      <div class="locationtbl col-lg-12">
        <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Series</p>
      </div>

      <?php if(session()->has('err_message')): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('err_message')); ?>

        </div>
      <?php endif; ?>
      <?php if(session()->has('success_message')): ?>
        <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('success_message')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
      <?php endif; ?>
      <div>
          <a href="<?php echo e(route('cp_series.create')); ?>" class="btn btn-md btn-primary">Add new Series</a>
      </div>
      <div class="view-table img-thumbnail">
        <table class="table">
          <thead>
            <tr class="firsttr">
              <th>#</th>
              <th>Name</th>
              <th>Category</th>
              <th>Number of posts</th>
              <th>creation date</th>
              <th>Actions</th>
            </tr>
          </thead>
            <tbody>
            <?php if(isset($serList)): ?>
              <?php $__currentLoopData = $serList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($ser->seriesname); ?></td>
                    <td><?php echo e($ser->category->catename); ?></td>
                    <td><?php echo e($ser->posts->count()); ?></td>
                    <td><?php echo e($ser->created_at); ?></td>
                    <td class="actionscss">
                      <div class="row catetable">
                        <a href="/cp_series/<?php echo e($ser->id); ?>/edit"><i class="far fa-edit text-primary"></i></a><a href="" data-class="cp_series/<?php echo e($ser->id); ?>/del" class="del-series"><i class="fas fa-trash-alt text-danger"></i></a>
                      </div>
                    </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
            </tbody>
        </table>        
        <?php if(isset($emptyser)): ?>
            <p class="noCates">No series added yet</p>
        <?php endif; ?>
      </div>
      <div class="card-footer clearfix">
      <?php if(isset($serList)): ?>
        <?php echo e($serList->links()); ?>

      <?php endif; ?>
      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/cp/series/cp_series.blade.php ENDPATH**/ ?>