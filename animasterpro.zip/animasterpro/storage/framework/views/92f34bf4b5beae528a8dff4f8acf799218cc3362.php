<?php $__env->startSection('content'); ?>
<div class="col-lg-9 viewertbl">
  <div class="container">
    <div class="row p-3">
      <div class="locationtbl col-lg-12">
        <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Members List</p>
      </div>

      <?php if(session()->has('err_message')): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('err_message')); ?>

        </div>
      <?php endif; ?>
      <?php if(session()->has('success_message')): ?>
        <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('success_message')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
      <?php endif; ?>
      <div class="row w-100">
        <a href="<?php echo e(route('cp_managemem.create')); ?>" class="btn btn-md btn-primary col-3">Add new member</a>
        <a id="showblkmem" class="btn btn-md btn-primary showblkmem col-3 ml-4" style="color: #fff; cursor:pointer;">Show blocked members only</a>
      </div>

        <div class="upper_mem_div mt-3">
            <div class="member_search mx-auto">
                <form action="" method="post">
                <?php echo csrf_field(); ?>
                    <label for="searchopt">Search by</label>

                    <select name="searchopt" id="searchopt" class= "form-control">
                        <option value="email">Email</option>
                        <option value="name">Name</option>
                        <option value="id">ID</option>
                    </select>

                    <input class="form-control" type="text" name="memsearchinput" id="memsearchinput" value=''>
                    <button class="btn btn-primary memsearch">Search</button>
                </form>
            </div>
        </div>
      </div>
      <div class="view-table img-thumbnail" id="view-table">
        <table class="table">
          <thead>
            <tr class="firsttr">
              <th class="border">#</th>
              <th class="border">Name</th>
              <th class="border">Email</th>
              <th class="border">Status</th>
              <th class="border">Actions</th>
            </tr>
          </thead>
            <tbody class="memberList" id="memberList">
            <?php $i = $members->perPage() * ($members->currentPage() - 1); ?>
                  <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($i++ + 1); ?></td>
                    <td><?php echo e($member->name); ?></td>
                    <td><?php echo e($member->email); ?></td>
                    <td><?php echo e($member->block ? 'Blocked' : 'Normal'); ?></td>
                    <td class="actionscss">
                      <div class="row catetable">
                        <a href="/cp_managemem/<?php echo e($member->id); ?>/edit"><i class="far fa-edit text-primary"></i></a>
                        <a href="/cp_managemem/<?php echo e($member->id); ?>/del"><i class="fas fa-trash-alt text-danger"></i></a>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>        
        <?php if(isset($emptymem)): ?>
            <p class="noCates" id="noCates">No Members till the moment</p>
        <?php endif; ?>
      </div>
      <div class="card-footer clearfix">
          <?php echo e($members->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\src\animaster\resources\views/cp/members/cp_members.blade.php ENDPATH**/ ?>