<?php $__env->startSection('content'); ?>

<div class="col-lg-9 viewertbl">
  <div class="container">
      <div class="row p-3">
          <div class="locationtbl col-lg-12">
              <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Add new page</p>
          </div>

          <?php if(session()->has('err_message')): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('err_message')); ?>

            </div>
          <?php endif; ?>
          <?php if(session()->has('success_message')): ?>
            <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('success_message')); ?>

            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>

          <?php if(isset($certainPage)): ?>
            <h3 class="card-title">Edit Page</h3>
          <?php else: ?>
            <h3 class="card-title">Add new Page</h3>
          <?php endif; ?>

          <?php if(isset($certainPage)): ?>
            <form role="form" class="mainform img-thumbnail mt-2 p-3" action="/cp_pages/<?php echo e($certainPage->id); ?>" method="post">
            <?php echo e(method_field('PUT')); ?>

          <?php else: ?>
            <form role="form" class="mainform img-thumbnail mt-2 p-3" action="<?php echo e(route('cp_pages.store')); ?>" method="post">
          <?php endif; ?>
            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label for="pagenameid">Page title</label>
                <?php if(isset($certainPage)): ?>
                  <input type="text" class="form-control" id="pagenameid" name="pagename" placeholder="Enter page title" value="<?php echo e($certainPage->pagename); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="pagenameid" name="pagename" placeholder="Enter page title">
                <?php endif; ?>
            </div>
                           
            <div class="form-group">
                <label for="pagecontentid">Page content</label>

                <?php if(isset($certainPage)): ?>

                <textarea class="form-control pagecontent" name="pagecontent" id="pagecontentid" rows="3" placeholder="Enter page content"><?php echo e($certainPage->pagecontent); ?></textarea>

                <?php else: ?>

                <textarea class="form-control pagecontent" name="pagecontent" id="pagecontentid" rows="3" placeholder="Enter category content"></textarea>

                <?php endif; ?>
            </div>

            <?php if(isset($certainPage)): ?>

              <button type="submit" class="btn btn-primary subton">Edit</button>

            <?php else: ?>

              <button type="submit" class="btn btn-primary subton">Add</button>

            <?php endif; ?>

            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/cp/pages/cp_addpage.blade.php ENDPATH**/ ?>