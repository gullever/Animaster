<?php $__env->startSection('content'); ?>
<div class="col-lg-9 viewertbl">
  <div class="container">
    <div class="row p-3">
      <div class="locationtbl col-lg-12">
        <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Manage Comments</p>
      </div>

      <?php if(session()->has('err_message')): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('err_message')); ?>

        </div>
      <?php endif; ?>
      <?php if(session()->has('success_message')): ?>
        <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('success_message')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
      <?php endif; ?>
        <div class="upper_mem_div mt-3">
            <div class="member_search mx-auto">
                <form action="" method="post">
                <?php echo method_field('post'); ?>
                <?php echo csrf_field(); ?>
                    <label for="searchopt">Search by</label>

                    <select name="comsearchopt" id="comsearchopt" class= "form-control">
                        <option value="value">Comment</option>
                        <option value="post_id">Post ID</option>
                        <option value="user_id">Member ID</option>
                    </select>

                    <input class="form-control" type="text" name="comsearchinput" id="comsearchinput" value=''>
                    <button class="btn btn-primary comsearch">Search</button>
                </form>
            </div>
        </div>
      </div>
      <div class="view-table img-thumbnail" id="view-table">
        <table class="table">
          <thead>
            <tr class="firsttr">
              <th class="border">#</th>
              <th class="border">Post title</th>
              <th class="border">Post ID</th>
              <th class="border">Member name</th>
              <th class="border">Member ID</th>
              <th class="border">Actions</th>
            </tr>
          </thead>
            <tbody class="memberList" id="memberList">
                  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <td><?php echo e($key + 1); ?></td>
                    <td><?php echo e($comment->post->title); ?></td>
                    <td><?php echo e($comment->post->id); ?></td>
                    <?php if($comment->role == "admin"): ?>
                    <td><?php echo e(App\Admin::where('id', 1)->first()->name); ?></td>
                    <?php else: ?>
                    <td><?php echo e($comment->user->name); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($comment->user->id); ?></td>
                    <td class="actionscss">
                      <div class="row catetable">
                        <a href="/cp_comment/<?php echo e($comment->id); ?>/show"><i class="fas fa-eye"></i></i></a>
                        <a href="/cp_comment/<?php echo e($comment->id); ?>/del"><i class="fas fa-trash-alt text-danger"></i></a>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>        
        <?php if(isset($emptycom)): ?>
            <p class="noCates" id="noCates">No comments till the moment</p>
        <?php endif; ?>
      </div>
      <div class="card-footer clearfix">
          <?php echo e($comments->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/cp/comments/comments.blade.php ENDPATH**/ ?>