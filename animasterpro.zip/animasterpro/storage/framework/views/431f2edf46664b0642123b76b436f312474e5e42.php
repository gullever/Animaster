<?php $__env->startSection('content'); ?>
<section class="page_main">
    <div class="container">
        <div class="row">

            <div class="page">
                <h5><?php echo e($thispage->pagename); ?></h5>

                <div class="errors_showshow">
                    <?php if(session()->has('err_message')): ?>
                    <div class="alert alert-danger generalerrorshow col-12" role="alert">
                        <?php echo e(session()->get('err_message')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(session()->has('success_message')): ?>
                        <div class="alert alert-success generalerrorshow col-12" role="alert">
                            <?php echo e(session()->get('success_message')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger generalerrorshow col-12">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="pge_body p-5"><?php echo html_entity_decode($thispage->pagecontent); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/page.blade.php ENDPATH**/ ?>