<?php $__env->startSection('title'); ?>
<title><?php echo e($cateinfo->catename); ?></title>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="category_main">
<div class="cate_layer">
    <div class="container">
        <div class="cate">
            <div class="row">
                <div class="card mb-3 col-12">
                    <div class="row no-gutters">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e($cateinfo->catename); ?></h5>
                            <p class="card-text"><?php echo e($cateinfo->catedesc); ?></p>
                        </div>
                    </div>
                </div>
                <?php if(isset($posts) && $posts->count() > 0): ?>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($post->series_id == 0): ?>
                            <a href="/watch/<?php echo e($post->id); ?>" class="col-lg-3 col-md-4 col-sm-6 col-12 epi_blk">
                        <?php else: ?>
                            <a href="/series/<?php echo e($post->id); ?>" class="col-lg-3 col-md-4 col-sm-6 col-12 epi_blk">
                        <?php endif; ?>
                                <div class="card episodes_card">
                                <?php if($post->image_src == 'native'): ?>
                                    <img src="<?php echo e(asset($post->image)); ?>" class="card-img img-fluid card_img_top" alt="<?php echo e($post->title); ?>">
                                <?php else: ?>
                                    <img src="<?php echo e($post->image); ?>" class="card-img img-fluid card_img_top" alt="<?php echo e($post->title); ?>">
                                <?php endif; ?>
                                    <div class="card-body">
                                        <p class="card-title"><?php echo e($post->title); ?></p>
                                        <div class="access"><i class="fa fa-eye" aria-hidden="true"></i><small class="ml-2"><?php echo e($post->views == NULL ? 0 : $post->views); ?></small></div>
                                    </div>
                                </div>
                            </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>

            <?php else: ?>
                <div class="no_data_div">
                    <p>There is no posts in this category</p>
                </div>
            <?php endif; ?>
            <?php if(isset($posts)): ?>
                <?php echo e($posts->links()); ?>

            <?php endif; ?>
        </div>
    </div>
</div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animasterpro\resources\views/category.blade.php ENDPATH**/ ?>