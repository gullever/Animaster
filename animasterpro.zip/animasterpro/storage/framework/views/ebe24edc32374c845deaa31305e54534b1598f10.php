<?php $__env->startSection('content'); ?>

<div class="col-lg-9 viewertbl">
  <div class="container">
      <div class="row p-3">
          <div class="locationtbl col-lg-12">
              <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Add new series</p>
          </div>

          <?php if(session()->has('err_message')): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('err_message')); ?>

            </div>
          <?php endif; ?>
          <?php if(session()->has('success_message')): ?>
            <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('success_message')); ?>

            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
          <?php if($cates->count() == 1 && $cates[0]->catename=="uncategorized"): ?>
              <div class="catemsg" style="min-height: 100vh; min-width: 100%;">
                  <h5>There is no categories added yet</h5>
                  <a href="<?php echo e(route('cp_categories.create')); ?>" class="btn btn-primary">Add category</a>
              </div>
            <?php else: ?>
          <?php if(isset($certainSer)): ?>
            <h3 class="card-title">Edit series</h3>
          <?php else: ?>
            <h3 class="card-title">Add new series</h3>
          <?php endif; ?>

          <?php if(isset($certainSer)): ?>
            <form role="form" class="mainform img-thumbnail mt-2 p-3 bordcard" action="/cp_series/<?php echo e($certainSer->id); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(method_field('PUT')); ?>

          <?php else: ?>
            <form role="form" class="mainform img-thumbnail mt-2 p-3 bordcard" action="<?php echo e(route('cp_series.store')); ?>" method="post" enctype="multipart/form-data">
          <?php endif; ?>
            <?php echo csrf_field(); ?>
          <!--            Series Name          --> 
            <div class="form-group">
                <label for="seriesname">Series name</label>
                <?php if(isset($certainSer)): ?>
                  <input type="text" class="form-control" id="seriesname" name="seriesname" placeholder="Enter series name" value="<?php echo e($certainSer->seriesname); ?>">
                <?php else: ?>
                  <input type="text" class="form-control" id="seriesname" name="seriesname" placeholder="Enter series name">
                <?php endif; ?>
            </div>
            <!--            Select Category          --> 
            <?php if(isset($certainSer)): ?>
            <div class="form-group">
                <p>Current categtogry: <?php echo e($certainSer->category->catename); ?></p>
                <label for="catelist" class="required">Category</label>
                <select id="catelist" name="catelist" class="form-control select2 catelist" style="width: 100%;">
                    <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if($cate->catename != "uncategorized"): ?>
                          <option><?php echo e($cate->catename); ?></option>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <?php else: ?>
            <div class="form-group">
                <label for="catelist" class="required">Category</label>
                <select id="catelist" name="catelist" class="form-control select2 catelist" style="width: 100%;">
                    <?php $__currentLoopData = $cates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($cate->catename != "uncategorized"): ?>
                          <option><?php echo e($cate->catename); ?></option>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <?php endif; ?>

            <!--            Upload Image          --> 
            <div class="form-group col-12 border pt-3 pb-3">
                <h5>Series image</h5>
                <i class="fas fa-exclamation-circle text-warning"></i><span class='text-muted ml-1'>Recommended size: 2000 x 600</span>
                <?php if(isset($certainSer)): ?>
                <h6 class="mt-4">Current Series image</h6>
                    <img class="img-thumbnail img-fluid mb-4" src="<?php echo e(asset($certainSer->image)); ?>" alt="">
                <?php endif; ?>
                <div class="choose_img mt-2">
                    <button id="choose_img-btn-1" data-class="upload-image" type="button" class="btn btn-primary">Upload</button>
                    <button id="choose_img-btn-2" data-class="image-link" type="button" class="btn btn-primary">Insert an URL</button>
                </div>

                <div class="img_targets mt-4">

                    <div class="upload-image">
                        <h6>Upload Image</h6>
                        <input type="file" name="postimgup"class="form-control-file" id="postimgup">
                    </div>

                    <div class="image-link">
                        <h6>Image URL</h6>
                        <div class="img-url border">
                            <div class="icon-link"><i class="fas fa-link"></i></div>
                            <?php if(isset($certainSer) && $certainSer->image_src != "native"): ?>
                                  <input type="url" value="<?php echo e($certainSer->image); ?>" name="postimglink"class="form-control-file" id="postimglink" style="display:block;">
                            <?php else: ?>
                                <input type="url" name="postimglink"class="form-control-file" id="postimglink">
                            <?php endif; ?>
                            
                        </div>
                    </div>
                
                </div>
            </div>    
       
            <div class="form-group">
                <label for="content">Series desription <span class='text-muted'> (Optional)</span></label>

                <?php if(isset($certainSer)): ?>

                <textarea class="form-control" name="sercontent" id="sercontent" rows="3" placeholder="Enter series descrioption"><?php echo e($certainSer->content); ?></textarea>

                <?php else: ?>

                <textarea class="form-control" name="sercontent" id="sercontent" rows="3" placeholder="Enter series descrioption"></textarea>

                <?php endif; ?>
            </div>

            

            <?php if(isset($certainSer)): ?>

              <button type="submit" class="btn btn-primary subton">Edit</button>

            <?php else: ?>

              <button type="submit" class="btn btn-primary subton">Add</button>

            <?php endif; ?>
            <?php endif; ?>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
        
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/cp/series/cp_addseries.blade.php ENDPATH**/ ?>