<?php $__env->startSection('content'); ?>
<div class="col-lg-9 viewertbl">
  <div class="container">
    <div class="row p-3">
      <div class="locationtbl col-lg-12">
        <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Pages</p>
      </div>

      <?php if(session()->has('err_message')): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('err_message')); ?>

        </div>
      <?php endif; ?>
      <?php if(session()->has('success_message')): ?>
        <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('success_message')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
      <?php endif; ?>
      <div>
          <a href="<?php echo e(route('cp_pages.create')); ?>" class="btn btn-md btn-primary">Add new page</a>
      </div>


   <?php if(isset($allpages) && $allpages->count() > 0): ?>
   <div class="col-12 img-thumbnail mt-4 mb-4 p-2">

    <div class="alert alert-success" id="pageordersuccess" role="alert"></div>

      <label><b>Pages view arrangement</b></label>
      <ul id="list-1" class="sortable pagessortlist">
      <?php $__currentLoopData = $allpages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li class="border draggable" id="item-1"><?php echo e($page->pagename); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
      <a id="savepagearrange" class="btn btn-primary" style="color: #fff">Save</a>
   </div>
   <?php endif; ?>
   
  
      <div class="view-table img-thumbnail">
        <table class="table">
          <thead>
            <tr class="firsttr">
              <th class="border">#</th>
              <th class="border">Title</th>
              <th class="border">Actions</th>
            </tr>
          </thead>
            <tbody>
            <?php $i = $pageList->perPage() * ($pageList->currentPage() - 1); ?>
            <?php if(isset($pageList) && $pageList->count() > 0): ?>
            <?php $__currentLoopData = $pageList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $pg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($i++ + 1); ?></td>
                <td class="border"><?php echo e($pg->pagename); ?></td>
                <td class="actionscss">
                  <div class="row catetable">
                    <a href="/page/<?php echo e($pg->pagename); ?>" target="_blank"><i class="fas fa-eye"></i></a>
                    <a href="/cp_pages/<?php echo e($pg->id); ?>/edit"><i class="far fa-edit text-primary"></i></a>
                    <a data-class="/cp_pages/<?php echo e($pg->id); ?>/del" class="page_delete"><i class="fas fa-trash-alt text-danger"></i></a>
                  </div>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </tbody>
        </table>        
        <?php if(isset($emptypage)): ?>
            <p class="noCates">No pages added yet</p>
        <?php endif; ?>
      </div>
      <div class="card-footer clearfix">
          <?php echo e($pageList->links()); ?>

      </div>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animasterpro\resources\views/cp/pages/cp_pages.blade.php ENDPATH**/ ?>