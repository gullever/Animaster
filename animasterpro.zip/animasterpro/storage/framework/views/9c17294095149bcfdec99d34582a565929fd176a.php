<?php $__env->startSection('content'); ?>
<div class="col-lg-9 viewertbl">
  <div class="container">
    <div class="row p-3">
      <div class="locationtbl col-lg-12">
        <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ Posts</p>
      </div>

      <?php if(session()->has('err_message')): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('err_message')); ?>

        </div>
      <?php endif; ?>
      <?php if(session()->has('success_message')): ?>
        <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
            <?php echo e(session()->get('success_message')); ?>

        </div>
      <?php endif; ?>
      <?php if($errors->any()): ?>
        <div class="alert alert-danger adminSettingMsg col-12 mt-1">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
      <?php endif; ?>
      <div>
          <a href="<?php echo e(route('cp_posts.create')); ?>" class="btn btn-md btn-primary">Add new post</a>
      </div>
      <div class="view-table img-thumbnail" id="view-table">
        <table class="table" id="tableeeee">
          <thead>
            <tr class="firsttr">
                <th>#</th>
                <th>Title</th>
                <th>Category</th>
                <th>Series</th>
                <th>View count</th>
                <th>Actions</th>
            </tr>
          </thead>
          <tbody>
          <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <td><?php echo e($key + 1); ?></td>
            <td><?php echo e($post->title); ?></td>
            <td><?php echo e($post->category->catename); ?></td>
            <?php if(empty($post->Series)): ?>
            <td>-</td>
            <?php else: ?>
            <td><?php echo e($post->Series->seriesname); ?></td>
            <?php endif; ?>
            <td><?php echo e(rand(300,7500)); ?></td>

            <td>
            <div class="row postactions">
                <a href="#"><i class="fas fa-eye"></i></i></a>
                <a href="/cp_posts/<?php echo e($post->id); ?>/edit"><i class="far fa-edit text-primary"></i></a>
                <a data-class="/cp_posts/<?php echo e($post->id); ?>/del" class="post_delete"><i class="fas fa-trash-alt text-danger"></i></a>
              </div>
            </td>
            
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
        <?php if(isset($emptypost)): ?>
            <p class="noPosts">No posts added yet</p>
        <?php endif; ?>
      </div>
      <div>
          <?php echo e($posts->links()); ?>

      </div>

    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\animaster\resources\views/cp/posts/index.blade.php ENDPATH**/ ?>