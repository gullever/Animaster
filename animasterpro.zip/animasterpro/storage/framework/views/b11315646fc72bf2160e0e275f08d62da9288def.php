<?php $__env->startSection('content'); ?>
<div class="col-lg-9 viewertbl">
  <div class="container">
      <div class="row p-3">
          <div class="locationtbl col-lg-12">
              <p><a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a> \ View comment</p>
          </div>

          <?php if(session()->has('err_message')): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('err_message')); ?>

            </div>
          <?php endif; ?>
          <?php if(session()->has('success_message')): ?>
            <div class="alert alert-success adminSettingMsg col-12 mt-1" role="alert">
                <?php echo e(session()->get('success_message')); ?>

            </div>
          <?php endif; ?>
          <?php if($errors->any()): ?>
            <div class="alert alert-danger adminSettingMsg col-12 mt-1">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
          <?php endif; ?>
        <a href="/cp_comment/<?php echo e($certaincom->id); ?>/del" class="btn btn-danger mb-2 mt-2">Delete this comment</a>
        <form role="form" class="col-12 p-3 img-thumbnail">
            

            <div class="form-group">
                <label for="comid">ID</label>
                <input type="text" class="form-control" id="comid" name="comid" value="<?php echo e($certaincom->id); ?>" readonly>
            </div>

            <div class="form-group">
                <label for="postid">Post ID</label>
                <input type="text" class="form-control" id="postID" name="postid" value="<?php echo e($certaincom->post_id); ?>" readonly>
            </div>

            <div class="form-group">
                <label for="posttitle">Post title</label>
                <input type="text" class="form-control" id="posttitle" name="posttitle" value="<?php echo e($certaincom->post->title); ?>" readonly>
            </div>

            <div class="form-group">
                <label for="userid">User ID</label>
                <input type="text" class="form-control" id="userid" name="userid" value="<?php echo e($certaincom->user_id); ?>" readonly>
            </div>
            <?php if($certaincom->role == "admin"): ?>
            <div class="form-group">
                <label for="username">User name</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo e(App\Admin::where('id', 1)->first()->name); ?>" readonly>
            </div>
            <?php else: ?>
            <div class="form-group">
                <label for="username">User name</label>
                <input type="text" class="form-control" id="username" name="username" value="<?php echo e($certaincom->user->name); ?>" readonly>
            </div>
            <?php endif; ?>

            <div class="form-group">
                <label for="comdate">Creation date</label>
                <input type="text" class="form-control" id="comdate" name="comdate" value="<?php echo e($certaincom->created_at); ?>" readonly>
            </div>

            <div class="form-group">
                <label for="comm">Comment</label>
                <textarea class="form-control" id="comm" rows="3" readonly><?php echo e($certaincom->value); ?></textarea>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('cp.layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\H.Riad\Desktop\src\animaster\resources\views/cp/comments/viewcomment.blade.php ENDPATH**/ ?>