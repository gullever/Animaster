<footer class="footer col-lg-12 order-2">
    <p class="copyright">© 2020 Animaster.  All rights reserved.</p>
</footer><?php /**PATH C:\Users\H.Riad\Desktop\animasterpro\resources\views/cp/layouts/admin_footer.blade.php ENDPATH**/ ?>