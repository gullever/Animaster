<footer class="footer col-lg-12 order-2">
    <p class="copyright">© 2020 Animaster.  All rights reserved.</p>
</footer>